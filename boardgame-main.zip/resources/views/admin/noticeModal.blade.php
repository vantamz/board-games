<div class="modal fade" id="noticeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="noticeModal">Add new Notice</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div>
                    <div class="form-group"><label for="inputDate" class="form-label">Date</label>
                        <input type="date" id="inputDate" class="form-control">
                    </div>
                </div>
                <br>
                <div class="form-group"><label for="inputDate" class="form-label">Tittle</label>
                    <input type="text" id="inputDate" class="form-control">
                </div>
                <div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" class="btn btn-primary">Save changes</button>
            </div>
        </div>
    </div>
</div>
