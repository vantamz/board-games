@extends('admin.layout')
@section('content')
<div class="container-fluid" style="padding-top: 20px">
    <div class="table-responsive" style="background-color: #fff;border-radius:15px 15px 15px 15px;padding:15px 15px 15px 15px">
        <table class="table">
            <thead>
                <thead>
                    <th>ID</th>
                    <th>Product ID</th>
                    <th>Order ID</th>
                    <th>Amount</th>
                    <th>Note</th>
                </thead>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>1</td>
                    <td>1</td>
                    <td>10</td>
                    <td>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam quaerat consectetur omnis.
                         Eos ab illum praesentium amet debitis rerum dolor soluta,
                         voluptas veniam pariatur atque facere sint sunt ipsa doloremque.</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>1</td>
                    <td>1</td>
                    <td>10</td>
                    <td>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam quaerat consectetur omnis.
                         Eos ab illum praesentium amet debitis rerum dolor soluta,
                         voluptas veniam pariatur atque facere sint sunt ipsa doloremque.</td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>1</td>
                    <td>1</td>
                    <td>10</td>
                    <td>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam quaerat consectetur omnis.
                         Eos ab illum praesentium amet debitis rerum dolor soluta,
                         voluptas veniam pariatur atque facere sint sunt ipsa doloremque.</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
@endsection
