@extends('shop.layout')
@section('content')
<div style="text-align: center">
    Complete Register
</div>
@endsection
