<title>Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<script src="<?php echo e(asset('BackEnd/js/ckeditor/ckeditor.js')); ?>"></script>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<link href="<?php echo e(asset('BackEnd/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all">
<!-- Custom Theme files -->
<link href="<?php echo e(asset('BackEnd/css/style-new.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
<!--js-->

<script src="<?php echo e(asset('BackEnd/js/admin/jquery-2.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('BackEnd/js/admin/bootstrap.js')); ?>"></script>
<!--icons-css-->

<link rel="stylesheet" href="<?php echo e(asset('BackEnd/css/all.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('BackEnd/css/style.css')); ?>">
<!--Google Fonts-->
<link href='//fonts.googleapis.com/css?family=Carrois+Gothic' rel='stylesheet' type='text/css'>
<link href='//fonts.googleapis.com/css?family=Work+Sans:400,500,600' rel='stylesheet' type='text/css'>
<!--static chart-->
<script src="<?php echo e(asset('BackEnd/js/Chart.js')); ?>"></script>
<!--//charts-->

<!--skycons-icons-->
<script src="<?php echo e(asset('BackEnd/js/admin/skycons.js')); ?>"></script>
<!--//skycons-icons-->

<script type="text/javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
<!--Full Calender-->
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@5.9.0/main.css' rel='stylesheet' />

<script src='https://cdn.jsdelivr.net/npm/fullcalendar@5.9.0/main.js'></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

<!--select2-->
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" /><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/layout/head.blade.php ENDPATH**/ ?>