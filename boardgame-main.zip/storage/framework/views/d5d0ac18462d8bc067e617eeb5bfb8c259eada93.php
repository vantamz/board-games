<div id="review_list">
    <div class="row">
        <div class="col-lg-6">
            <div class="box_rating">
                <h5>
                    Overrall
                </h5>
                <div class="d-flex justify-content-center">
                    <h4>
                        <?php
                        $point=0;
                        $count=0;
                        ?>
                            <div hidden>
                            <?php $__currentLoopData = $rate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($count++); ?>

                            <?php echo e($point+=$item->rate); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <?php if($count!=0): ?>
                        <?php echo e(number_format($point/$count, 2)); ?>

                        <?php else: ?>
                        0.0
                        <?php endif; ?>
                    </h4>
                    <span class="far fa-star"></span>
                </div>
            </div>
        </div>
        <div class="p-t-20">
            <?php if($comments!=null): ?>
            <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="review_item">
                <div class="media">
                    <div class="row">
                        <div class="col-lg-1">
                            <img src="<?php
            if($comment->role_user==3)
            echo asset('Img/customer-avatar/'.$comment->customerRelation->avatar);
            elseif($comment->role_user==1||$comment->role_user==2)
            echo asset('Img/user-img/'.$comment->staffRelation->avatar);
            else
            echo asset('Img/unsigned.png');
        ?>" alt="" class="comment_radius">
                        </div>
                        <div class="col-lg-11">
                            <div class="review_body">
                                <h4><?php echo e($comment->userRelation->name); ?></h4>
                                <span>
                                    <?php if($comment->RatingRelation!=null): ?>
                                    <?php echo e($comment->RatingRelation->rate); ?>

                                    <?php else: ?>
                                    0
                                    <?php endif; ?>
                                </span>point
                            </div>
                        </div>
                    </div>
                </div>
                <p><?php echo e($comment->comment); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/shop/comment/comment.blade.php ENDPATH**/ ?>