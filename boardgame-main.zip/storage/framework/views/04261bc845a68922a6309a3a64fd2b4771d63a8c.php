<?php $__env->startSection('adminContent'); ?>
<div class="inner-block-other">
    <div class="table-responsive table-admin">
        <table class="table table-responsive overflow-auto cell-border hover todo-table" id="table_id">
            <thead>
                <tr>
                    <th>Id</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Status</th>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
                    <th>Edit</th>
                    <?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <th>Delete</th>
                    <?php endif; ?>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="id"><?php echo $user->id; ?></td>
                    <td class="name"><?php echo $user->name; ?></td>
                    <td class="email"><?php echo $user->email; ?></td>
                    <td class="status">
                        <?php if($user->status==0): ?>
                        Not active
                        <?php elseif($user->status==1): ?>
                        Active
                        <?php endif; ?>
                    </td>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit user')): ?>
                    <td>
                        <button class="btn btn-warning editUser" data-id="<?php echo $user->id; ?>" data-toggle="modal"
                            data-target="#exampleModal"><i class="far fa-pencil"></i></button>
                    </td><?php endif; ?>
                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <td>
                        <button class="btn btn-danger deleteUser" data-toggle="modal" data-target="#userDelete"><i
                                class="fal fa-trash"></i></button>
                    </td>
                    <!--<td>-->
                    <!--    <a class="btn btn-danger" href="<?php echo e(url('admin/user-lock/'.$user->id)); ?>"><i class="fal fa-lock"></i></a>-->
                    <!--</td>-->
                    <?php endif; ?>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php echo $__env->make('admin.user.userCreate_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="modal fade" id="userDelete" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><h3 class="modal-title" id="exampleModalLabel">Confirm Lock</h3></div>
                    <div class="col-lg-6 justify-content-end d-flex"><button type="button" class="btn btn-secondary" data-dismiss="modal">X</button></div>
                </div>
            </div>
            <div class="modal-body">
                Lock this staff?
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><button type="button" class="btn btn-secondary"
                            data-dismiss="modal">Close</button></div>
                    <div class="col-lg-6">
                        <form action="<?php echo e(url('admin/user-lock')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('GET'); ?>
                            <input type="text"id="v_idUser" name="userId" hidden>
                            <button type="submit" type="button" class="btn btn-primary">Yes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).on('click', '.editUser', function () {
        var _this = $(this).parents('tr');
        $('#v_id').val(_this.find('.id').text());
        $('#v_name').val(_this.find('.name').text());
        $('#v_email').val(_this.find('.email').text());
    });
</script>
<script>
    $(document).on('click', '.deleteUser', function () {
        var _this = $(this).parents('tr');
        $('#v_idUser').val(_this.find('.id').text());
    });

</script>
<script>
    $(document).ready(function () {
        $('#table_id').DataTable();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/user/user.blade.php ENDPATH**/ ?>