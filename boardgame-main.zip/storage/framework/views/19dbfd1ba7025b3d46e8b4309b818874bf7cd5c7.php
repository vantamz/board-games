<div class="container-black">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-sm-12">
                <h3>About Us</h3>
                Trần Võ Đăng Khoa <br>
                Phone: 0382024592<br>
                Email: 0306181328@gmail.com<br><br>
                Hà Quốc Thịnh<br>
                Phone: 0358707811<br>
                Email: 0306181369@gmail.com<br>
            </div>
            <div class="col-lg-4 col-sm-12">
                <h3>Newsletter</h3>
                <p>Stay update with our latest</p>
                <form action="#">
                    <div class="input-group mb3">
                        <input type="text" class="form-control" id="email" placeholder="Enter email">
                        <label for="email"></label>
                        <button class="btn btn-warning"><i class="fa fa-long-arrow-right text-white" aria-hidden="true"></i></button>
                    </div>
                </form>
            </div>
            <div class="col-lg-4 col-sm-12">
                <h3>Facebook Feed</h3>
                <div class="pt-3">
                    <iframe src="https://www.facebook.com/plugins/page.php?href=https%3A%2F%2Fwww.facebook.com%2FTK-Boardgame-100556532443552&tabs=event&width=340&height=130&small_header=false&adapt_container_width=true&hide_cover=false&show_facepile=true&appId" width="340" height="130" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share"></iframe>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-black">
    <p class="text-center pb-5 mb-0">Copyright <i class="fa fa-copyright text-white" aria-hidden="true"></i>2021 All rights reserved | 
    This template is made by Someone</p>
</div>







<script>
    function searchVisible() {
        document.getElementById("search_input_box").removeAttribute("class", "visible_hidden");
    }

</script>
<script>
    function searchHidden() {
        document.getElementById("search_input_box").setAttribute("class", "visible_hidden");
    }

</script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--Cart-->
<script src="<?php echo e(asset('FrontEnd/js/cart-bag.js')); ?>"></script>
<!-- JavaScript -->
<script src="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>

<!-- CSS -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/alertify.min.css" />
<!-- Default theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/default.min.css" />
<!-- Semantic UI theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/semantic.min.css" />
<!-- Bootstrap theme -->
<link rel="stylesheet" href="//cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/css/themes/bootstrap.min.css" />
<script>
    /*  $('.dropdown.keep-open').on({
     //fires after dropdown is shown instance method is called (if you click anywhere else)
     "shown.bs.dropdown": function() { this.close= true; },
    //when dropdown is clicked
    "click": function() { this.close= false; },
    //when close event is triggered
    "hide.bs.dropdown":  function() { return this.close; }
});
 */
    document.getElementById("keep-open").addEventListener('click', function () {
        event.stopPropagation();
    });

</script>
<!-- Messenger Plugin chat Code -->
    <div id="fb-root"></div>

    <!-- Your Plugin chat code -->
    <div id="fb-customer-chat" class="fb-customerchat">
    </div>

    <script>
      var chatbox = document.getElementById('fb-customer-chat');
      chatbox.setAttribute("page_id", "100556532443552");
      chatbox.setAttribute("attribution", "biz_inbox");

      window.fbAsyncInit = function() {
        FB.init({
          xfbml            : true,
          version          : 'v12.0'
        });
      };

      (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));
    </script>
<?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/shop/partials/footer.blade.php ENDPATH**/ ?>