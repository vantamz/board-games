<?php $__env->startSection('adminContent'); ?>
<div class="inner-block">
    <div class="d-flex bd-highlight mb-3">
        <div class="me-auto p-2 bd-highlight">
            <h2>customer</h2>
        </div>
    </div>

    <div class="table-responsive table-admin mb-4">
        <table class="table table-responsive overflow-auto row-border hover todo-table" id="table_id">
            <thead>
                <th >ID</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Birth</th>
                <th>Gender</th>
                <th>Avatar</th>
                <th>Status</th>
                <th>Edit</th>
                <th>Delete</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="id"><?php echo e($customer->id); ?></td>
                    <td><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->phone); ?></td>
                    <td><?php echo e($customer->birth); ?></td>
                    <td>
                        <?php if($customer->sex==1): ?>
                        Male
                        <?php elseif($customer->sex==2): ?>
                        Female
                        <?php elseif($customer->sex==3): ?>
                        Other
                        <?php endif; ?>
                    </td>
                    <td><img src="<?php echo e(asset('Img/customer-avatar/'.$customer->avatar)); ?>" alt=""
                            style="width: 150px;height:150px"></td>
                    <td><?php echo e($customer->status==0? "Not active": "Active"); ?></td>
                    <td>
                        <a href="<?php echo e(url('admin/customer-edit',$customer->id)); ?>" class="btn btn-warning editUser"><i
                                class="far fa-pencil"></i></a>

                    </td>
                    <td>
                        <button class="btn btn-danger customerLock" data-toggle="modal" data-target="#exampleModal" href="#exampleModal"><i
                                class="fal fa-trash"></i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
    </div>
</div>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><h3 class="modal-title" id="exampleModalLabel">Confirm Lock</h3></div>
                    <div class="col-lg-6 justify-content-end d-flex"><button type="button" class="btn btn-secondary" data-dismiss="modal">X</button></div>
                </div>

                

            </div>
            <div class="modal-body">
                Lock customer?
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><button type="button" class="btn btn-secondary"
                            data-dismiss="modal">Close</button></div>
                    <div class="col-lg-6">
                        <form action="<?php echo e(url('admin/customer-lock')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('GET'); ?>
                            <input type="text" id="v_id" name="customerId" hidden>
                            <button type="submit" type="button" class="btn btn-primary">Yes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).on('click', '.customerLock', function () {
        var _this = $(this).parents('tr');
        $('#v_id').val(_this.find('.id').text());
    });

</script>
<script>
    $(document).ready(function () {
        $('#table_id').DataTable();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/customer/customer.blade.php ENDPATH**/ ?>