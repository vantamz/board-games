<!-- Modal -->
<div class="modal fade" id="modalRegister" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content" style="background-color: transparent!important;border-style:none">
            <section class="ftco-section">
                <div class="container-fluid">
                    <div class="row justify-content-center">
                        <div class="col-md-12 col-lg-10">
                            <div class="wrap d-md-flex">
                                <div class="text-wrap p-4 p-lg-5 text-center d-flex align-items-center order-md-last">
                                    <div class="text w-100">
                                        <div class="d-flex justify-content-end close-button">
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <h2>Welcome to TK Board Game</h2>
                                        <p>Don't have an account?</p>
                                        <button type="buttoz"
                                            class="btn btn-white btn-outline-white Ripple-effect radius-50"
                                            data-bs-toggle="modal" data-bs-target="#ModalLogin"
                                            data-bs-dismiss="modal">Sign Up</button>
                                    </div>
                                </div>

                                <div class="login-wrap p-4 p-lg-5">
                                    <div class="d-flex">
                                        <div class="w-100">
                                            <h3 class="mb-4">Sign In</h3>
                                        </div>
                                        <div class="w-100">
                                            <p class="social-media d-flex justify-content-end">
                                                <a href="#"
                                                    class="social-icon d-flex align-items-center justify-content-center"><span
                                                        class="fab fa-facebook-f"></span></a>
                                                <a href="#"
                                                    class="social-icon d-flex align-items-center justify-content-center"><span
                                                        class="fab fa-twitter"></span></a>
                                            </p>
                                        </div>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('UserLogin')); ?>" class="signin-form">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mb-3">

                                            <label class="label mb-3"
                                                for="name"><?php echo e(__('E-Mail Address')); ?></label>
                                            <input type="email" class="form-control log-input" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>"
                                                required autocomplete="email" autofocus placeholder="Email">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label class="label mb-3"
                                                for="password"><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control log-input"
                                                placeholder="Password" required <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                                                autocomplete="current-password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group mb-3">
                                            <button type="submit"
                                                class="form-control btn primary-btn submit px-3 radius-50 Ripple-effect"><?php echo e(__('Sign In')); ?></button>

                                        </div>

                                    </form>
                                    <div class="form-group d-md-flex mb-3">
                                        <div class="w-50 text-left remember">
                                            <input type="checkbox" id="rememberCheck" checked>
                                            <span class="checkmark"></span>
                                            <label class="checkbox-wrap checkbox-primary mb-0 label-color"
                                                for="rememberCheck">Remember Me</label>
                                        </div>
                                        <div class="w-50 d-flex justify-content-end text-md-right">
                                            <?php if(Route::has('password.request')): ?>
                                            <a href="<?php echo e(route('password.request')); ?>" class="text-log"><?php echo e(__('Forgot Password?')); ?></a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="ModalLogin" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content" style="background-color: transparent!important;border-style:none">
            <section class="ftco-section" >
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-12 col-lg-10">
                            <div class="wrap d-md-flex">
                                <div class="text-wrap p-4 p-lg-5 text-center d-flex align-items-center order-md-last">
                                    <div class="text w-100">
                                        <h2>Welcome to TK Board Game</h2>
                                        <p>Already have an account?</p>
                                        <a type="button" data-bs-toggle="modal" data-bs-target="#ModalRegister"
                                        data-bs-dismiss="modal" class="btn btn-white btn-outline-white Ripple-effect radius-50">Sign In</a>
                                    </div>
                                </div>

                                <div class="login-wrap p-4 p-lg-5">
                                    <div class="d-flex">
                                        <div class="w-100">
                                            <h3 class="mb-4">Sign Up</h3>
                                        </div>
                                    </div>
                                    <form method="POST" action="<?php echo e(route('create')); ?>" class="signin-form">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group mb-3">

                                            <label class="label mb-3"
                                                for="name"><?php echo e(__('E-Mail Address')); ?></label>
                                            <input type="email" class="form-control log-input"
                                            name="email" value="<?php echo e(old('email')); ?>"
                                                required autocomplete="email" placeholder="Email">
                                        </div>
                                        <div class="form-group mb-3">
                                            <label class="label mb-3"
                                                for="password"><?php echo e(__('Password')); ?></label>
                                            <input type="password" class="form-control log-input"
                                                placeholder="Password" required name="password" required>
                                        </div>
                                        <div class="form-group mb-3">
                                            <label class="label mb-3"
                                                for="name"><?php echo e(__('name')); ?></label>
                                            <input type="text" class="form-control log-input"
                                                placeholder="name" required name="name" required >
                                        </div>
                                        <div class="form-group mb-3">
                                            <label class="label mb-3"
                                                for="phone"><?php echo e(__('phone')); ?></label>
                                            <input type="text" class="form-control log-input"
                                                placeholder="phone" required name="phone" required >
                                        </div>
                                        <div class="form-group mb-3">
                                            <label class="label mb-3"
                                                for="phone"><?php echo e(__('birth')); ?></label>
                                            <input type="date" class="form-control log-input"
                                                placeholder="birth" required name="birth" required >
                                        </div>
                                        <div class="form-group mb-3">
                                            <button type="submit"
                                                class="form-control btn primary-btn submit px-3 radius-50 Ripple-effect"><?php echo e(__('Register')); ?></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
        </div>
    </div>
</div>
<?php /**PATH D:\boardgame-main\resources\views/register.blade.php ENDPATH**/ ?>