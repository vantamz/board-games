<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="col-lg-4 col-md-6 p-b-40">
    <div class="single-product">
        <a href="<?php echo e(route('single',$product->id)); ?>">
            <?php if($product->stock==0): ?>
            <span class="onsale">Out of stock</span>
            <?php elseif($product->promotionRelation->id!=1): ?>
                                                    <span class="onsale">Sale <?php echo e($product->promotionRelation->rate); ?>%
                                                        off</span>
                                                    <?php endif; ?>
            <div class="wrap" style="top: 0px;z-index: 200;position: relative;">
                <div class="box-img">
                    <img class="img-fluid" src="<?php echo e(asset('Img/product-img/'.$product->image)); ?>" alt="">
                </div>
            </div>
            <div class="product-details">
                <h6> <a href="<?php echo e(route('single',$product->id)); ?>"><?php echo e($product->name); ?></a></h6>
                <div class="price">
                                                            <div class="row">
                                                                <?php if($product->promotionRelation->id!=1): ?>
                                                                <div class="col-lg-6">
                                                                    <h6 class="price-color">
                                                                        $<?php echo e($product->promotion_price); ?>

                                                                    </h6>
                                                                </div>
                                                                <div class="col-lg-6">
                                                                    <h6 class="l-through">$<?php echo e($product->price); ?></h6>
                                                                </div>
                                                                <?php else: ?>
                                                                <div class="col-lg-12">
                                                                    <h6 class="price-color">
                                                                        $<?php echo e($product->promotion_price); ?>

                                                                    </h6>
                                                                </div>
                                                                    <?php endif; ?>
                                                            </div>
                                                        </div>
                <hr>
                <div class="prd-bottom">
                    <div class="row p-b-20">
                        <div class="d-flex justify-content-center">
                            <?php if($product->stock!=0): ?>
                            <div class="tooltip col-lg-6">
                                <a onclick="AddCart(<?php echo e($product->id); ?>)" href="javascript:">
                                    <i class="fal fa-shopping-bag fa-3x addCart"></i>
                                </a><span class="tooltiptext">Add Cart</span>
                            </div>
                            <?php endif; ?>
                            <div class="tooltip col-lg-6">
                                <a href="#">
                                    <?php if(auth()->check()): ?>
                                        <?php
                                            $check = auth()->user()->favorites()->where('product_id', $product->id)->first();
                                        ?>
                                        <?php if($check): ?>
                                            <i class="fas fa-heart-circle fa-3x addFav removefav active" data-target="<?php echo e($product->id); ?>"></i>
                                        <?php else: ?>
                                            <i class="fas fa-heart-circle fa-3x addFav addtofav" data-target="<?php echo e($product->id); ?>"></i>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <i class="fas fa-heart-circle fa-3x addFav addtofav" data-target="<?php echo e($product->id); ?>"></i>
                                    <?php endif; ?>
                                </a><span class="tooltiptext">Favortire</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </a>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/shop/category/category-render.blade.php ENDPATH**/ ?>