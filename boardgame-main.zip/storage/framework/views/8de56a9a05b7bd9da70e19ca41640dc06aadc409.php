
<!--header start here-->
<div class="header-main">
    <div class="header-left">
        <div class="logo-name">
            <a href="index.html">
                <h1>TK Boardgame</h1>
            </a>
        </div>
        <div class="clearfix"> </div>
    </div>
    <div class="header-right">
        <div class="profile_details">
            <ul>
                <li class="dropdown profile_details_drop">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <div class="profile_info" style="padding-top: 30px">
                            <?php if(auth()->guard()->guest()): ?>
                            <img src="<?php echo e(asset('Img/unsigned.png')); ?>" alt="" class="cen profile_image">
                            <h4>Admin</h4>
                            <?php else: ?>
                            <img src="<?php echo e(asset('Img/user-img/'.Auth::user()->staffRelation->avatar)); ?>" alt="" class="cen profile_image">
                            <div class="user-name">
                                <p><?php echo e(Auth::user()->name); ?></p>
                                <span>Administrator</span>
                            </div>
                            <i class="fa fa-angle-down lnr"></i>
                            <i class="fa fa-angle-up lnr"></i>
                            <div class="clearfix"></div>
                            <?php endif; ?>
                        </div>
                    </a>
                    <ul class="dropdown-menu drp-mnu">
                        <li> <a href="#"><i class="fa fa-user"></i> Profile</a> </li>
                        <li><a href="<?php echo e(route('logout')); ?>" class="logout-btn" onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i> Logout</a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                            </li>

                    </ul>
                </li>
            </ul>
        </div>
        <div class="clearfix"> </div>
    </div>
    <div class="clearfix"> </div>
</div>
<!--heder end here-->
<?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/layout/header.blade.php ENDPATH**/ ?>