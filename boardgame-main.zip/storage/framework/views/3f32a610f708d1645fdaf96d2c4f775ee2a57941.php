<?php $__env->startSection('adminContent'); ?>
<div class="inner-block-other">
    <div class="row d-flex mb-4">
        <div class="col-lg-8">
            <h1>Staff</h1>
        </div>

        <div class="col-lg-4 ">
            <div class="d-flex justify-content-end">
                <a href="<?php echo e(route('staffs.create')); ?>" class="btn btn-primary">Add</a>
            </div>

        </div>
    </div>

    <div class="table-responsive table-admin">
        <table class="table table-responsive overflow-auto row-border hover todo-table" id="table_id">
            <thead>
                <th>ID</th>
                <th>Email</th>
                <th>Name</th>
                <th>Birth</th>
                <th>Sex</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Status</th>
                <th>Avatar</th>
                <th>Edit</th>
                <th>Lock</th>
            </thead>
            <tbody>
                <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <?php echo e($staff->id); ?>

                    </td>
                    <td>
                        <?php echo e($staff->userRelation->email); ?>

                    </td>
                    <td>
                        <?php echo e($staff->name); ?>

                    </td>
                    <td>
                        <?php echo e($staff->birth); ?>

                    </td>
                    <td>
                        <?php echo e($staff->sex); ?>

                    </td>
                    <td>
                        <?php echo e($staff->phone); ?>

                    </td>
                    <td>
                        <?php echo e($staff->address); ?>

                    </td>
                    <td>
                        <?php if($staff->status==0): ?>
                        Not active
                        <?php elseif($staff->status==1): ?>
                        Active
                        <?php endif; ?>
                    </td>
                    <td>
                        <img src="<?php echo e(asset('Img/user-img/'.$staff->avatar)); ?>" alt="" style="width: 150px;height:150px">
                    </td>
                    <td>
                        <a href="<?php echo e(route('staffs.edit',$staff->id)); ?>" class="btn btn-warning"><i
                                class="far fa-pencil"></i></a>
                    </td>
                    <td>
                        <button class="btn btn-danger" data-toggle="modal" data-target="#exampleModal"><i
                                class="fal fa-trash"></i></button>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><h3 class="modal-title" id="exampleModalLabel">Confirm Lock</h3></div>
                    <div class="col-lg-6 justify-content-end d-flex"><button type="button" class="btn btn-secondary" data-dismiss="modal">X</button></div>
                </div>

                

            </div>
            <div class="modal-body">
                Lock this staff?
            </div>
            <div class="modal-footer">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><button type="button" class="btn btn-secondary"
                            data-dismiss="modal">Close</button></div>
                    <div class="col-lg-6">
                        <form action="<?php echo e(route('staffs.destroy',$staff->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <input type="text" value="<?php echo e($staff->id); ?>" name="staff_id" hidden>
                            <input type="text" value="<?php echo e($staff->user); ?>" name="user_id" hidden>
                            <button type="submit" type="button" class="btn btn-primary">Yes</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function () {
        $('#table_id').DataTable({
            "pageLength": 4
        });
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/staff/staff.blade.php ENDPATH**/ ?>