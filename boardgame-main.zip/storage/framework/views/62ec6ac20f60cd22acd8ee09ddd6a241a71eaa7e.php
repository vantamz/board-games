<html>

<head>
    <?php echo $__env->make('shop/partials/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <?php echo $__env->make('shop.partials.header-content', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--Content-->
    <?php echo $__env->make('register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <!--//Content-->
    <!--Footer-->
    <?php echo $__env->make('shop.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!--//Footer-->
</body>

</html>
<?php /**PATH D:\boardgame-main\resources\views/shop/layout.blade.php ENDPATH**/ ?>