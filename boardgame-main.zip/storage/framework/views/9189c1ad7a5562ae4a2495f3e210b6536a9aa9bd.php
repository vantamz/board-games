<?php $__env->startSection('content'); ?>
<section class="banner-category">
    <div class="container">
        <div class="d-flex flex-wrap align-items-center justify-content-end" style="padding: 90px 120px 100px 0;">
            <div>
                <h1 class="color-w"><b>Login Page</b></h1>
                <nav class="d-flex align-items-center color-w">
                    <a href>
                        Home
                        <span style="  display: inline-block;
                        margin: 0 10px;"><i class="fal fa-long-arrow-right"></i></span>
                    </a>
                    <a href>
                        Login
                    </a>
                </nav>
            </div>
        </div>
    </div>
</section>
<section class="ftco-section" style="padding: 30px 0px 150px 0px">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 col-lg-10">
                <div class="wrap d-md-flex">
                    <div class="text-wrap p-4 p-lg-5 text-center d-flex align-items-center order-md-last">
                        <div class="text w-100">
                            <h2>Welcome to TK Board Game</h2>
                            <p>Don't have an account?</p>
                            <a type="button" href="<?php echo e(route('registerPage')); ?>" class="btn btn-white btn-outline-white Ripple-effect radius-50">Sign Up</a>
                        </div>
                    </div>

                    <div class="login-wrap p-4 p-lg-5">
                        <div class="d-flex">
                            <div class="w-100">
                                <h3 class="mb-4">Sign In</h3>
                            </div>
                            <!--<div class="w-100">-->
                            <!--    <p class="social-media d-flex justify-content-end">-->
                            <!--        <a href="#"-->
                            <!--            class="social-icon d-flex align-items-center justify-content-center"><span-->
                            <!--                class="fab fa-facebook-f"></span></a>-->
                            <!--        <a href="#"-->
                            <!--            class="social-icon d-flex align-items-center justify-content-center"><span-->
                            <!--                class="fab fa-twitter"></span></a>-->
                            <!--    </p>-->
                            <!--</div>-->
                        </div>
                        <form method="POST" action="<?php echo e(route('UserLogin')); ?>" class="signin-form">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">

                                <label class="label mb-3"
                                    for="name"><?php echo e(__('E-Mail Address')); ?></label>
                                <input type="email" class="form-control log-input" <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>"
                                    required autocomplete="email" autofocus placeholder="Email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-3">
                                <label class="label mb-3"
                                    for="password"><?php echo e(__('Password')); ?></label>
                                <input type="password" class="form-control log-input"
                                    placeholder="Password" required <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                                    autocomplete="current-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-3">
                                <button type="submit"
                                    class="form-control btn primary-btn submit px-3 radius-50 Ripple-effect"><?php echo e(__('Sign In')); ?></button>
                            </div>

                        </form>
                        <div class="form-group d-md-flex mb-3">
                            <div class="w-50 text-left remember">
                                <!--<input type="checkbox" id="rememberCheck" checked>-->
                                <!--<span class="checkmark"></span>-->
                                <!--<label class="checkbox-wrap checkbox-primary mb-0 label-color"-->
                                <!--    for="rememberCheck">Remember Me</label>-->
                            </div>
                            <div class="w-50 d-flex justify-content-end text-md-right">
                                <?php if(Route::has('password.request')): ?>
                                <a href="<?php echo e(url('reset-password-page')); ?>" class="text-log"><?php echo e(__('Forgot Password?')); ?></a>
                                <?php endif; ?>
                            </div>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shop.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/shop/login-page.blade.php ENDPATH**/ ?>