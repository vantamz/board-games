<?php $__env->startSection('adminContent'); ?>
<div class="inner-block-other">

    <div class="row">

        <div class="col-lg-3">
            <?php if(!empty($editData)): ?>
            <form action="<?php echo e(url('admin/supplier-update/'.$editData->id)); ?>" method="POST">
            <?php else: ?>
            <form action="<?php echo e(url('admin/supplier-store')); ?>" method="POST">
            <?php endif; ?>
                <?php echo csrf_field(); ?>
                <div class="table-admin">
                    <div>
                        <label for="roleName" class="form-label">Supplier's Name</label>
                        <input type="text" id="roleName" name="name" class="form-control" value="<?php echo e(!empty($editData)? $editData->name:''); ?>">
                    </div>
                    <div>
                        <label for="User" class="form-label">Supplier's Address</label>
                        <input type="text" id="User" name="address" class="form-control" value="<?php echo e(!empty($editData)? $editData->address:''); ?>">
                    </div>
                    <div>
                        <label for="User" class="form-label">Supplier's Phone</label>
                        <input type="text" id="User" name="phone" class="form-control" value="<?php echo e(!empty($editData)? $editData->phone:''); ?>">
                    </div>
                    <div>
                        <label for="User" class="form-label">Supplier'Email</label>
                        <input type="text" id="User" name="email" class="form-control" value="<?php echo e(!empty($editData)? $editData->email:''); ?>">
                    </div>

                    <div class="d-flex justify-content-end padding-top-35">
                        <?php if(!empty($editData)): ?>
                        <button type="submit" class="btn btn-primary">Update</button>
                        <?php else: ?>
                        <button type="submit" class="btn btn-primary">Add</button>
                        <?php endif; ?>
                        
                    </div>
                </div>
            </form>
        </div>

        <div class="col-lg-9">
            <div class="table-responsive table-admin">
                <table class="table table-responsive overflow-auto row-border hover todo-table" id="table_id">
                    <thead>
                        <th>ID</th>
                        <th>Supplier's Name</th>
                        <th>Supplier's Adress</th>
                        <th>Supplier's Phone</th>
                        <th>Supplier's Email</th>
                        <th>Action</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->address); ?></td>
                            <td><?php echo e($item->phone); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td>
                                <p>
                                    <a class="btn btn-success" data-toggle="collapse"
                                        href="#collapseExample<?php echo e($item->id); ?>" role="button" aria-expanded="false"
                                        aria-controls="collapseExample" style="width: 110px">
                                        <i class="fal fa-cog"></i> Action
                                    </a>
                                </p>
                                <div class="collapse" id="collapseExample<?php echo e($item->id); ?>">
                                    <div class="card card-body">
                                        <br>
                                        <a href="<?php echo e(url('admin/supplier-edit/'.$item->id)); ?>" class="btn btn-warning btn-block">Edit</a>
                                        <br>
                                        <button  class="btn btn-danger btn-block" data-toggle="modal" data-target="#exampleModal">Delete</button>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><h3 class="modal-title" id="exampleModalLabel">Confirm Lock</h3></div>
                    <div class="col-lg-6 justify-content-end d-flex"><button type="button" class="btn btn-secondary" data-dismiss="modal">X</button></div>
                </div>
            </div>
      <div class="modal-body">
        Are you sure to delete ?
      </div>
      <div class="modal-footer">
                <div class="row">
                    <div class="col-lg-6 d-flex justify-content-start">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                    <div class="col-lg-6">
                        <form action="<?php echo e(url('admin/supplier-delete/'.$item->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" type="button" class="btn btn-primary">Yes</button>
                        </form>
                    </div>
                </div>
            </div>
    </div>
  </div>
</div>

<script>
    $(document).ready(function () {
        $('#table_id').DataTable(

        );
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/supplier/supplier.blade.php ENDPATH**/ ?>