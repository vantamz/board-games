<?php if(Session::has("Cart")!=null): ?>
<?php $product = app('App\Models\product'); ?>
<section class="shopping-cart spad" id="listCart">
    <div class="container">
        <div class="row">
            <div class="cart-table table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Image</th>
                            <th class="p-name">Product Name</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = Session::get("Cart")->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $productInfo=$product::find($item['productInfo']->id);
                        ?>
                        <tr>
                            <td class="cart-pic first-row"><img src="<?php echo e(asset('Img/product-img/'.$item['productInfo']->image)); ?>" alt="" width="70%"></td>
                            <td class="cart-title first-row">
                                <h4><?php echo e($item['productInfo']->name); ?></h4>
                                <br>
                                Stocking: <?php if($productInfo->stock<$item['quanty']): ?>
                                <span style="color:red"><?php echo e($productInfo->stock); ?></span>
                                <?php else: ?>
                                <?php echo e($productInfo->stock); ?>

                                <?php endif; ?>
                            </td>
                            <td class="p-price first-row" style="font-size:25px">$<?php echo e($item['productInfo']->promotion_price); ?></td>
                            <td class="qua-col first-row">
                                <div class="quantity">
                                    <div class="input-group inline-group">
                                        <div class="input-group-prepend">
                                            <button class="btn btn-outline-secondary btn-minus" onclick="UpdateItem(<?php echo e($item['productInfo']->id); ?>)" >
                                                <i class="fa fa-minus"></i>
                                            </button>
                                        </div>
                                        <input class="form-control" min="1" name="quantity"
                                            id="quanty-item<?php echo e($item['productInfo']->id); ?>" value="<?php echo e($item['quanty']); ?>"
                                            type="number">
                                             <?php if($productInfo->stock >$item['quanty']): ?>
                                        <div class="input-group-append">
                                            <button  class="btn btn-outline-secondary btn-plus" onclick="UpdateItem(<?php echo e($item['productInfo']->id); ?>)">
                                                <i class="fa fa-plus"></i>
                                            </button>
                                        </div>
                                        <?php else: ?>
                                        <div class="input-group-append">
                                            <button disabled  class="btn btn-outline-secondary btn-plus" >
                                                <i class="fa fa-plus"></i>
                                            </button>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <br>
                                <?php if($productInfo->stock ==$item['quanty']): ?>
                                The product has reached the maximum quantity
                                <?php endif; ?>
                            </td>
                            <td class="total-price first-row" style="font-size:25px">$<?php echo e(($item['productInfo']->price-($item['productInfo']->price*$item['productInfo']->promotionRelation->rate/100))*$item['quanty']); ?></td>
                            <td class="close-td first-row"><a class="btn"
                                    onclick="UpdateItem(<?php echo e($item['productInfo']->id); ?>)"><i class="fal fa-save"></i></a>
                            </td>
                            <td class="close-td first-row"><a class="btn"
                                    onclick="DeleteItem(<?php echo e($item['productInfo']->id); ?>)"><i
                                        class="fas fa-times"></i></a>
                                    </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col-lg-4">
                    <div class="cart-buttons">
                        <a href="<?php echo e(route('home')); ?>" class="cart-btn continue-shop">Continue shopping</a>
                        <a href="<?php echo e(route('clear-cart')); ?>" class="cart-btn up-cart">clear all</a>
                    </div>

                </div>

                <div class="col-lg-4 offset-lg-4">
                    <div class="proceed-checkout">
                        <ul>
                            <li class="subtotal">
                                <div class="row">
                                    <div class="col-lg-6">Quantity</div>
                                    <div class="col-lg-6 d-flex justify-content-end">
                                        <span><?php echo e(Session::get('Cart')->totalQuanty); ?></span>
                                    </div>
                                </div>
                            </li>
                            <li class="cart-total">
                                <div class="row">
                                    <div class="col-lg-6">Total</div>
                                    <div class="col-lg-6 d-flex justify-content-end">
                                        <span>$<?php echo e(number_format(Session::get('Cart')->totalPrice)); ?></span>
                                    </div>
                                </div>
                            </li>
                        </ul>
                        <a href="<?php echo e(route('checkout')); ?>" class="proceed-btn Ripple-effect">PROCEED TO CHECK OUT</a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
<?php else: ?>
<div class="container">
    <div class="text-center empty_bag">
        <img src="<?php echo e(asset('Img/empty-bag.png')); ?>" alt="">
        <div class="notice mb-3">
        <b>your shopping cart is empty</b>
        </div>
        <a href="<?php echo e(route('home')); ?>" class="primary-btn">buy now</a>
    </div>
</div>
<?php endif; ?>

<script>
    $('.btn-plus, .btn-minus').on('click', function (e) {
        const isNegative = $(e.target).closest('.btn-minus').is('.btn-minus');
        const input = $(e.target).closest('.input-group').find('input');
        if (input.is('input')) {
            input[0][isNegative ? 'stepDown' : 'stepUp']()
        }
    })


</script>
<?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/shop/ListCart.blade.php ENDPATH**/ ?>