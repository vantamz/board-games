<?php $__env->startSection('adminContent'); ?>
<div class="inner-block-other">
    <div class="row">
        <div class="col-lg-3">
            <div class="table-admin">
                <?php if(!empty($ProductTypeSingle)): ?>
                <form action="<?php echo e(route('productType-update',$ProductTypeSingle->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php else: ?>
                    <form action="<?php echo e(route('productType-store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php endif; ?>

                        <div>
                            <label for="roleName" class="form-label">Product Type Name</label>
                            <input type="text" id="roleName" class="form-control" name="product_type_name"
                                value="<?php echo e(!empty($ProductTypeSingle)? $ProductTypeSingle->product_type_name:''); ?>" required>
                        </div>
                        <div class="d-flex justify-content-end padding-top-35">
                            <?php if(!empty($ProductTypeSingle)): ?>
                            <button class="btn btn-primary" type="submit">Update</button>
                            <?php else: ?>
                            <button class="btn btn-primary" type="submit">Save</button>
                            <?php endif; ?>
                        </div>
                    </form>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="table-responsive table-admin">
                <table class="table table-responsive overflow-auto row-border hover todo-table" id="table_id">
                    <thead>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $productTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="id"><?php echo e($productType->id); ?></td>
                            <td><?php echo e($productType->product_type_name); ?></td>
                            <td><a href="<?php echo e(route('productType-edit',$productType->id)); ?>" class="btn btn-success"><i
                                        class="far fa-pencil"></i></a></td>
                            <td>
                                <button class="btn btn-danger deleteProductType" data-toggle="modal" data-target="#exampleModal"><i
                                        class="fal fa-trash"></i></button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
                <div class="row">
                    <div class="col-lg-6 justify-content-start d-flex"><h3 class="modal-title" id="exampleModalLabel">Confirm Lock</h3></div>
                    <div class="col-lg-6 justify-content-end d-flex"><button type="button" class="btn btn-secondary" data-dismiss="modal">X</button></div>
                </div>
            </div>
      <div class="modal-body">
        Are you sure to lock ?
      </div>
      <div class="modal-footer">
                <div class="row">
                    <div class="col-lg-6 d-flex justify-content-start">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                    <div class="col-lg-6">
                        <form action="<?php echo e(url('admin/productType-delete')); ?>" method="GET">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('GET'); ?>
                            <input type="input"  id="v_id" name="productTypeId" hidden></input>
                            <button type="submit" type="button" class="btn btn-primary">Yes</button>
                        </form>
                    </div>
                </div>
            </div>
    </div>
  </div>
</div>

<script>
    $(document).on('click', '.deleteProductType', function () {
        var _this = $(this).parents('tr');
        $('#v_id').val(_this.find('.id').text());
    });

</script>

<script>
    $(document).ready(function () {
        $('#table_id').DataTable(
            {"pageLength": 10}
        );
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/product/productType.blade.php ENDPATH**/ ?>