<?php $userNotification = app('App\Models\notification'); ?>
<?php $promotion = app('App\Models\promotion'); ?>
<?php $product = app('App\Models\product'); ?>
<?php $productKeep = app('App\Models\invoice'); ?>
<?php $customer = app('App\Models\customer'); ?>
<div class=" border-bottom header-color header-nav">
    <?php if(Auth::check()): ?>
     <?php
    $dateNow=date("Y-m-d h:m:s");
    $customer=$customer::where('user_id',Auth::user()->id)->first();
    $productKeepInfo=$productKeep::where('customer_id', $customer->id)->where('status','=',1)->where('keep_product','=',1)->get();
    $abc=0;
    foreach ($productKeepInfo as $item) {
        if ($item->created_at<$dateNow && $item->payment_method==1) {
            $invoiceExpress=$productKeep::find($item->id);
           $abc++;
           $invoiceExpress->status=0;
           $invoiceExpress->save();
        }
    }
    ?>
    <?php endif; ?>
    <div class="container">
        <div class="row">
            <div class="md-12">
                <ul>
                    <li style="float: left;line-height:50px">
                        <i class="fad fa-phone-alt"></i> Hotline: 0382024592
                    </li>
                    <li style="padding-left: 40px;padding-right: 40px;">
                        <div class="dropdown" id="keep-open">
                            <a href="<?php echo e(route('cart')); ?>" class=" link dropdown-toggle" id="dropdownCart"
                                data-bs-toggle="dropdown"><i class="fal fa-bags-shopping fa-2x"></i>
                                <?php if(Session::has('Cart') != null): ?>
                                <span class="badge badge-pill badge-danger" style="color: #000"
                                    id="quanty-show"><?php echo e(Session::get('Cart')->totalQuanty); ?></span>
                                <?php else: ?>
                                <span class="badge badge-pill badge-danger" id="quanty-show">0</span>
                                <?php endif; ?>
                            </a>
                            <ul class="dropdown-menu  cart" aria-labelledby="dropdownCart" role="menu">
                                <li>
                                    <div style="padding: 15px 0px 15px 0px">
                                        <div id="change-item-cart">
                                            <?php if(Session::has('Cart') != null): ?>
                                            <?php
                                            $cartCount=0;
                                            ?>
                                            <?php $__currentLoopData = Session::get("Cart")->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $cartCount++;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cartCount>3): ?>
                                            <div style="height:550px;overflow:auto">
                                                <?php else: ?>
                                                <div style="overflow:auto">
                                                    <?php endif; ?>
                                                    <div style="padding-top: 15px;padding-bototm:15px">
                                                        <table class="table">
                                                            <tbody>
                                                                <?php $__currentLoopData = Session::get("Cart")->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr style="border-bottom: 1px solid #fff!important">
                                                                    <td>
                                                                        <div class="cart-detail-img">
                                                                            <img
                                                                                src="<?php echo e(asset('Img/product-img/'.$item['productInfo']->image)); ?>">
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="row">
                                                                            <div class="col-lg-12 text-info">
                                                                                $<?php echo e($item['productInfo']->price-($item['productInfo']->price*$item['productInfo']->promotionRelation->rate/100)); ?>

                                                                                x <?php echo e($item['quanty']); ?>

                                                                            </div>
                                                                            <div class="col-lg-12">
                                                                                <b><?php echo e($item['productInfo']->name); ?></b>
                                                                            </div>
                                                                        </div>
                                                                    </td>
                                                                    <td>
                                                                        <div class="cart-close">
                                                                            <button
                                                                                data-id="<?php echo e($item['productInfo']->id); ?>"
                                                                                class="btn"><i
                                                                                    class="fas fa-times"></i></button>
                                                                        </div>
                                                                    </td>
                                                                </tr>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="total-section text-center checkout row">
                                                    <div class="col-lg-6">
                                                        Total:
                                                    </div>
                                                    <div class="col-lg-6">
                                                        <span
                                                            class="text-info">$<?php echo e(Session::get('Cart')->totalPrice); ?></span>
                                                    </div>
                                                </div>
                                                <?php else: ?>
                                                <div style="padding: 15px 15px 15px 15px">There no product in your
                                                    Cart.
                                                    Please
                                                    choose some thing.</div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="row">

                                            <div
                                                class="col-lg-12 col-sm-12 col-12 text-center checkout d-flex justify-content-end">
                                                <a href="<?php echo e(route('cart')); ?>" class="btn btn-primary">CART</a>
                                            </div>
                                        </div>
                                </li>
                            </ul>
                        </div>
                    </li>
                    <li style="padding-left: 20px;margin-right: 20px;border-left: 1px solid #353940;">
                        <?php if(auth()->guard()->guest()): ?>
                    <li>
                        <div class="dropdown">
                            <a href="<?php echo e(route('loginPage')); ?>" class="link"><i class="fas fa-sign-in-alt fa-2x"></i></a>
                            
                        </div>
                    </li>
                    <?php else: ?>
                    <li style="float: right;line-height:50px;padding-left:20px;padding-right:20px">
                        <a class="dropdown-toggle" href="#" id="dropdownMenuLink" data-bs-toggle="dropdown"
                            aria-expanded="false" style="color: #fff">
                            <?php echo e(Auth::user()->name); ?>

                        </a>
                        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <?php if(auth()->check() && auth()->user()->hasAnyRole('admin|staff')): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('admin')); ?>">Admin Dashboard</a>
                            </li>
                            <?php endif; ?>
                            <?php if(auth()->check() && auth()->user()->hasRole('customer')): ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('profile-user')); ?>"><i class="fal fa-user"></i>
                                    <span style="padding-left: 10px">Profile</span></a></li>
                            <li><a href="<?php echo e(route('invoice-shop')); ?>" class="dropdown-item"><i
                                        class="far fa-file-invoice"></i><span
                                        style="padding-left: 15px">Invoice</span></a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('favorite')); ?>" class="dropdown-item">
                                    <i class="far fa-heart"></i>
                                    <span style="padding-left: 15px">Favorite</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('redeem-code')); ?>" class="dropdown-item">
                                    <i class="far fa-credit-card"></i>
                                    <span style="padding-left: 15px">Redeem code</span>
                                </a>
                            </li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                          document.getElementById('logout-form').submit();"><i
                                        class="fal fa-portal-exit"></i>
                                    <span style="padding-left: 8px"><?php echo e(__('Logout')); ?></span>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                    <li style="float: right;line-height:50px;padding-left:20px;padding-right:20px">
                        <div class="btn-group">
                            <a type="button" class="btn " data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-bell" style="color: #fff"></i>
                            </a>
                            <?php
                            $notifications=$userNotification::where('user_id','=',Auth::user()->id)->where('status','=',1)->get();
                            $count=$userNotification::where('user_id','=',Auth::user()->id)->where('status','=',1)->count();
                            $number=0;
                            $promotionCheck=$promotion::where('status',1)->get();
                            $dateNow=date("Y-m-d");
                            $dateCount=0;
                            foreach ($promotionCheck as $item) {
                            if($item->end_date<$dateNow) {
                                $products=$product::find($item->product_id);
                                $products->promotion_id=1;
                                $products->promotion_price=$products->price;

                                $products->save();
                                $item->status=0;
                                $item->save();
                                }
                                }
                                ?>
                                <span class="badge badge-pill badge-danger"><?php echo e($count); ?></span>
                                <ul class="dropdown-menu">
                                    <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $number++;
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($number>2): ?>
                                    <div style="height:350px;overflow:auto">
                                        <?php else: ?>
                                        <div style="overflow:auto">
                                            <?php endif; ?>
                                            <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a class="dropdown-item"
                                                    href="<?php echo e(url('notification-status/'.$notification->id)); ?>"
                                                    onclick="notificationStatus(<?php echo e($notification->id); ?>)">
                                                    <div class="row">
                                                        <div class="col align-self-start">
                                                            <?php echo e($notification->content); ?>

                                                        </div>
                                                        <div class="col align-self-start">
                                                            <?php echo e(date('d/m/Y', strtotime($notification->created_at))); ?>

                                                        </div>
                                                    </div>
                                                </a>
                                                <hr>
                                            <li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>

                                        <div class="container" style="width: 250px;">
                                            You have <?php echo e($number); ?> notification
                                        </div>
                                        <?php if($number!=0): ?>
                                        <div class="d-grid gap-2">
                                            <a href="<?php echo e(url('notification-all-status')); ?>"
                                                class="btn btn-info btn-block" style="color: #fff">Mark all
                                                notifications</a>
                                        </div>
                                        <?php endif; ?>

                                </ul>
                        </div>
                    </li>


                    <?php endif; ?>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<!--Nav Bar-->
<div class="container">
    <div style="margin: auto;
    text-align:center;">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><img src="<?php echo e(asset('FrontEnd/img/logo-new.png')); ?>"
                class="logo" alt="">
            <span
                class="title_shop">TK
                Board Game Store</span></a>
    </div>
    <hr>
    <div>
        <nav class="navbar navbar-expand-lg nav-index navbar-light ">
            <div class="container">
                <button class="navbar-toggler " type="button" data-bs-toggle="collapse"
                    data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                    aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse " id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <div class="menu-background"><a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                            </div>
                        </li>
                        <li class=" nav-item">
                            <div class="menu-background"><a class="nav-link" href="<?php echo e(url('category/0')); ?>">Category</a>
                            </div>
                        </li>
                        <li class=" nav-item">
                            <div class="menu-background"><a class="nav-link" href="<?php echo e(route('about-us')); ?>">About
                                    Us</a>
                            </div>
                        </li>
                        <li class=" nav-item">

                        </li>
                        <li class="nav-item">

                        </li>
                        <li class="nav-item">
                            <div style="padding-top: 15px">
                                <button class="btn search_button" onclick="searchVisible()"><i
                                        class="fal fa-search"></i></button>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </div>
    <div id="search_input_box" class="visible_hidden">
        <div class="container">
            <form action="<?php echo e(route('search')); ?>" class="d-flex justify-content-between">
                <input type="text" class="form-control-search" id="search_input" placeholder="Search Here"
                    name="keyword">
                <button class="btn_search" type="submit"></button>
                <span id="close_search" title="Close Search" onclick="searchHidden()"><i
                        class="fal fa-times"></i></span>
            </form>
        </div>
    </div>
</div>

<!--//Nav Bar-->
<?php /**PATH D:\boardgame-main\resources\views/shop/partials/header-content.blade.php ENDPATH**/ ?>