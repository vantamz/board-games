<?php if(Session::has("Cart")!=null): ?>
<?php
                                            $cartCount=0;
                                            ?>
                                            <?php $__currentLoopData = Session::get("Cart")->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                            $cartCount++;
                                            ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cartCount>3): ?>
                                            <div style="height:550px;overflow:auto">
                                                <?php else: ?>
                                                <div style="overflow:auto">
                                                <?php endif; ?>
<div style="padding-top: 15px;padding-bototm:15px">
    <table class="table">
        <tbody>
            <?php $__currentLoopData = Session::get("Cart")->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr style="border-bottom: 1px solid #fff!important">
                <td>
                    <div class="cart-detail-img">
                        <img src="<?php echo e(asset('Img/product-img/'.$item['productInfo']->image)); ?>">
                    </div>
                </td>
                <td>
                    <div class="row">
                        <div class="col-lg-12 text-info">
                            $<?php echo e($item['productInfo']->price-($item['productInfo']->price*$item['productInfo']->promotionRelation->rate/100)); ?> x <?php echo e($item['quanty']); ?>

                        </div>
                        <div class="col-lg-12"><b><?php echo e($item['productInfo']->name); ?></b></div>
                    </div>
                </td>
                <td>
                    <div class="cart-close">
                        <button data-id="<?php echo e($item['productInfo']->id); ?>" class="btn"><i
                                class="fas fa-times"></i></button>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
<div class="total-section text-center checkout row">
    <div class="col-lg-6">
        Total:
    </div>
    <div class="col-lg-6">
        <span class="text-info">$<?php echo e(number_format(Session::get('Cart')->totalPrice)); ?></span>
        <input type="number" value="<?php echo e(Session::get('Cart')->totalQuanty); ?>" id="quanty-cart" hidden>
    </div>
    <p>

    </p>
</div>
<?php else: ?>
<div style="padding: 15px 15px 15px 15px">There no product in your Cart. Please choose some thing.</div>
<input type="number" value="0" id="quanty-cart" hidden>
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/shop/shopping-cart.blade.php ENDPATH**/ ?>