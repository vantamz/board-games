<?php $__env->startSection('adminContent'); ?>
<div class="inner-block-other">
    <div class="row">
        <div class="col-lg-3">
            <div class="table-admin">
                <form action="<?php echo e(route('roleStore')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="roleName" class="form-label">Role Name</label>
                        <input type="text" name="name" id="roleName" class="form-control" required>
                    </div>
                    <div class="d-flex justify-content-end padding-top-35">
                        <button class="btn btn-primary" type="submit">SAVE</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-9">
            <div class="table-responsive table-admin">
                <table class="table">
                    <thead>
                        <th style="width: 50%">ID</th>
                        <th style="width: 50%">Role Name</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width: 50%"><?php echo e($role->id); ?></td>
                            <td style="width: 50%"><?php echo e($role->name); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/user/role.blade.php ENDPATH**/ ?>