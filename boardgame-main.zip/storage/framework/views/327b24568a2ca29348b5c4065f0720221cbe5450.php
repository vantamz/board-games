<html>
<head>
    <?php echo $__env->make('admin.layout.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="page-container">
        <div class="left-content">
            <div class="mother-grid-inner">
                <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div>
                    <?php echo $__env->yieldContent('adminContent'); ?>
                </div>
            </div>

        </div>
        <div class="clearfix"> </div>
    </div>
</body>
<footer>
    <?php echo $__env->make('admin.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel\boardgame-main\resources\views/admin/layout/layout.blade.php ENDPATH**/ ?>