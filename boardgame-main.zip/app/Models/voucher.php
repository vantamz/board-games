<?php

namespace App\Models;

use App\Models\supplier;
use App\Models\promotion;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class voucher extends Model
{
    protected $table='voucher';
    use HasFactory;
    
    
    
}

